#include "mbed.h"
#include "rtos.h"
#include "can_api.h"

#include "device.h"
#include "PinNames.h"
#include "PeripheralNames.h"
#include "can_helper.h"


//#define RECEIVER
#define SENDER

CAN can1(p9, p10);
//CAN can2(p34, p33);
DigitalOut led1(LED1);
DigitalOut led2(LED2);
char counter = 0;
char queueCounter = 0;
volatile int read = 0;
CANMessage msgIn;	

typedef struct {
		CANMessage queue[20];
		uint16_t read_pos;
		uint16_t write_pos;
		uint16_t count;
} outputRingbuf;

outputRingbuf recMsgs;


uint32_t storeRecMessages(CANMessage sentMsg){
	__disable_irq();
	if (recMsgs.count < 512){
		recMsgs.queue[recMsgs.write_pos].len = sentMsg.len;
		recMsgs.queue[recMsgs.write_pos].format = sentMsg.format;
		recMsgs.queue[recMsgs.write_pos].id = sentMsg.id;
		for (int i = 0; i < sentMsg.len;i++){
			recMsgs.queue[recMsgs.write_pos].data[i] = sentMsg.data[i];
		}
		
		recMsgs.count++;
		if (recMsgs.write_pos < 512) {
			recMsgs.write_pos++;
		} else {
			recMsgs.write_pos = 0;
		}
		
		
	} else {
		printf("Sent messages buffer overflow\n");
	}	
	__enable_irq();
}

CANMessage dequeueOutput (void){
	CANMessage msg;
	__disable_irq();
	if (recMsgs.count > 0){
		msg.format = recMsgs.queue[recMsgs.read_pos].format;
		msg.id = recMsgs.queue[recMsgs.read_pos].id;
		msg.len = recMsgs.queue[recMsgs.read_pos].len;
		msg.type = recMsgs.queue[recMsgs.read_pos].type;
		for (int i = 0; i < recMsgs.queue[recMsgs.read_pos].len;i++){
			msg.data[i] = recMsgs.queue[recMsgs.read_pos].data[i];
		}
		recMsgs.count--;
		if (recMsgs.read_pos > 0){
			recMsgs.read_pos--;
		} else {
			recMsgs.read_pos = 512;
		}
	} else {
		msg.id = 0;
	}
	__enable_irq();
	return msg;
}


void CAN_thread(void const *args) {
		int id = 1337;
		CANMessage msg;
		while (true) {
        led2 = !led2;
				msg.data[0] = 0xff;
				msg.data[1] = 0;
				msg.data[2] = 0xff;
				msg.data[3] = 0;
				msg.data[4] = 0xff;
				msg.data[5] = 0;
				msg.data[6] = 0xff;
				msg.data[7] = counter&0x7ff;
				msg.len = 8;
				msg.id = id;
				msg.format = CANStandard;
				msg.type = CANData;
        if(can1.write(msg)) {
					printf("package\n\n\n\n");
					counter++;
					printf("Data sent: %d", msg.data[0]);
					printf("%d", msg.data[1]);
					printf("%d", msg.data[2]);
					printf("%d", msg.data[3]);
					printf("%d", msg.data[4]);
					printf("%d", msg.data[5]);
					printf("%d", msg.data[6]);
					printf("%d\n", msg.data[7]);
					printf("Id sent: %d\n", msg.id);
					printf("len sent: %d\n", msg.len);
					printf("format sent: %d\n", msg.format);
					printf("type sent: %d\n", msg.type);
					id++;
        } 
        Thread::wait(2000);
    }
}

void CAN_REC_thread(void const *args) {
	
	while (1) {
		if (recMsgs.count >= 10){
			//while (recMsgs.count > 0){
				//CANMessage data = dequeueOutput();
				for (int i = 0; i < 10; i++){
					printf("msg id %d\n",recMsgs.queue[i].id);
					printf("last inbound msg: %d", recMsgs.queue[i].data[7]);
					printf("%d", recMsgs.queue[i].data[6]);
					printf("%d", recMsgs.queue[i].data[5]);
					printf("%d", recMsgs.queue[i].data[4]);
					printf("%d", recMsgs.queue[i].data[3]);
					printf("%d", recMsgs.queue[i].data[2]);
					printf("%d", recMsgs.queue[i].data[1]);
					printf("%d\n", recMsgs.queue[i].data[0]);
					printf("msg len %d\n",recMsgs.queue[i].len);
					printf("msg type %d\n",recMsgs.queue[i].type);
				}
				recMsgs.count = 0;
				queueCounter = 0;
			//}
		}
  }
}


extern "C" void HardFault_Handler(){
    error("hardfault\n");
}

extern "C" void BusFault_Handler(){
    error("busfault\n");
}

extern "C" void UsageFault_Handler(){
    error("usagefault\n");
}

extern "C" void MemManage_Handler(){
    error("mmufault\n");
};

//extern "C" void CANIRQHandler(void){
void CANIRQHandler(void){
  __disable_irq;
	if(can1.read(msgIn)){
		if (queueCounter < 10 && msgIn.len > 0 ){
			//storeRecMessages(msgIn);
			recMsgs.queue[queueCounter].id = msgIn.id;
			recMsgs.queue[queueCounter].len = msgIn.len;
			memcpy(recMsgs.queue[queueCounter].data,msgIn.data,msgIn.len);
			recMsgs.queue[queueCounter].format = msgIn.format;
			recMsgs.queue[queueCounter].type = msgIn.type;
			queueCounter++;
			recMsgs.count++;
			led2 = !led2;
		}
	}
	__enable_irq;
}


extern "C" void CANIRQHandler2(void){
    printf("Interrupt\n"); 
}
 
int main() {
	can1.reset();
	can1.frequency(500000);
	can1.mode(CAN::Normal);
	recMsgs.count = 0;
	recMsgs.read_pos = 0;
	recMsgs.write_pos = 0;
	for (int i = 0; i < 20; i++){
		recMsgs.queue[i].id = 0;
		recMsgs.queue[i].len = 0;
		for (int j = 0; j < 8; j++){
			recMsgs.queue[i].data[j] = 0;
		}			
	}
	printf("start\n");
	#ifdef SENDER
			Thread thread(CAN_thread);
	#endif
	#ifdef RECEIVER
			Thread threadRec(CAN_REC_thread,NULL,osPriorityNormal);
			//can2.attach(&CANIRQHandler2);
			can1.attach(&CANIRQHandler);
			/*        NVIC_SetVector(CAN_IRQn, (uint32_t)CANIRQHandler);
							NVIC_SetPriority(CAN_IRQn, 0);       //highest priority
							//enable ADC interrupt
							NVIC_EnableIRQ(CAN_IRQn);
*/
			//_irq[(IRQ_RX.attach(&CANIRQHandler);
			//can_irq_set(&_can, (CanIrqType)type, 1);
	#endif
	while (1);
	/*while (read == 1) {
			
		//if (read == 1){
			can1.read(msgIn);
			printf("msg data %d\n",msgIn.data[0]);
		 //}
			read = 0;
	 
	}*/
}
